import mongoose from 'mongoose';
const trackSchema = new mongoose.Schema({
  sessionId: String,
  eventType: String,
  page: String,
  timestamp: String,
  browser: String,
  duration: Number,
  scrollPercent: Number,
  tag: String,
  text: String,
}, { timestamps: true });

export default mongoose.model('Track', trackSchema);