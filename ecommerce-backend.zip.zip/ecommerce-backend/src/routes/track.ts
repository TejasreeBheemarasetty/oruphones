import express from 'express';
import  Track  from '../models/Track';
const router = express.Router();

// Save tracking data
router.post('/', async (req, res) => {
  try {
    const activity = new Track(req.body);
    await activity.save();
    res.status(201).json({ message: 'Tracked successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error tracking user', err });
  }
});

// ✅ Get tracking data for dashboard
router.get('/', async (req, res) => {
  try {
    const activities = await Track.find().sort({ timestamp: -1 }).limit(100);
    res.json(activities);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch activity data', err });
  }
});

export default router;