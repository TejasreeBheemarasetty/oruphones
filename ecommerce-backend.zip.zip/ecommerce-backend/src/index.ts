import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Track from './models/Track';
import trackRoutes from './routes/track';
dotenv.config(); // Load variables from .env file

const app = express();
const PORT = process.env.PORT || 5000;
const uri = process.env.MONGODB_URI || ''; // MongoDB URI from .env

app.use(cors());
app.use(express.json());
// Connect to MongoDB
mongoose
  .connect(uri, {
    dbName: 'tracking-db',
  })
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB error:', err));
app.use('/api/track', trackRoutes);
// POST route to save user behavior
app.post('/api/track', async (req, res) => {
  try {
    const data = new Track(req.body);
    await data.save();
    res.status(201).json({ message: 'Data saved' });
  } catch (err) {
    console.error('Error saving data:', err);
    res.status(500).json({ error: 'Something went wrong' });
  }
});
import Product from './models/Product';
app.post('/api/products', async (req, res) => {
  try {
    const { title, brand, price, image, description } = req.body;
    const product = new Product({ title, brand, price, image, description });
    await product.save();
    res.status(201).json({ message: 'Product added' });
  } catch (err) {
    res.status(500).json({ message: 'Error saving product', err });
  }
});
app.get('/api/products', async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (err) {
    console.error('Failed to fetch products:', err);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});
app.get('/api/products/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: 'Product not found' });
  }
});
// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});